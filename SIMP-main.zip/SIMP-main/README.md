<html lang="in">

<head>

				<title>Love You</title>

				

				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

				<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

				

</head>

<body>

				<input class="nama" type="text" placeholder="Masukan Nama Panggilan" id="nama">

								<br><br>

								<button class="aw" id="aw">Sudahh</button>

				

				<script>

							$(document).ready(function(){

  $("#aw").click(function(){

    $("#aw").fadeOut(500);

    $("#nama").fadeOut(500);

    $("#ha").fadeIn(1500);

    $("#hai").fadeIn(3000);

    $("#jadi").fadeIn(5500);

    $("#aku").fadeIn(8500);

    $("#sesuatu").fadeIn(10500);

    $("#apa").fadeIn(12500);

    

    $("#ha").fadeOut(300);

    $("#hai").fadeOut(300);

    $("#jadi").fadeOut(300);

    $("#aku").fadeOut(300);

    $("#sesuatu").fadeOut(300);

    

    

  });

});

		$(document).ready(function() {

		$("#aw").click(function(){

						var name = $("#nama").val()

						$("#hai").html(name)

						$("#nama").val("")

				});

				});

			</script>

				

				

				<div class="semua" id="semua">

								

					<div class="kedua">

							<p class="ha" id="ha">Haii</p>

							<p class="hai" id="hai"></p>

							<p class="jadi" id="jadi">Jadi ginii</p>

							<p class="aku" id="aku">Aku mau ngomong</p>

							<p class="sesuatu" id="sesuatu">Sesuatu sama kamu</p>

							

							<button class="apa" id="apa">Apa tuhh ? <br> (CLICK)</button>							

					</div>

					

					<div class="ketiga" id="ketiga">

									

		<p class="tapi" id="tapi">Tapi sebelum itu</p>

	<p class="denger" id="denger">Denger musik dulu yuk</p>

		

			<audio src="https://raw.githubusercontent.com/rifkipriyatna/Katakan-Cinta/main/web.mp3" controls id="musik" class="musik">Play</audio>

			<button class="next" id="next">Next</button>

			

			

			

			

			

			<script>

							$(document).ready(function(){

  $("#apa").click(function(){  

    $("#tapi").fadeIn(3000);

    $("#denger").fadeIn(5000);

    $("#apa").fadeOut(200);

    $("#tapi").fadeOut(300);

    $("#denger").fadeOut(300);

    $("#musik").fadeIn(7000);

    $("#next").fadeIn(7500);

    

    

    });

});

			</script>					

					</div>

					

					<div class="keempat">

<div id="div1" class="nembak"><p>Haii Aku mau ngomong sesuatu sama kamu</p></div>

<div id="div2" class="bahwa"><p>Kita kan sudah lama kenal</p></div>

<div id="div3" class="sebener"><p>Dari main bareng</p></div>

<div id="div4" class="makan"><p>Makan bareng</p></div>

<div id="div5" class="jalan"><p>Jalan jalan bareng</p></div>

<div id="div6" class="chat"><p>Chatan dan telpon bareng</p></div>

<div id="div7" class="semuanya"><p>Semuanya bareng</p></div>

<div id="div8" class="jadi"><p>Jadi gini</p></div>

  				<button class="buka" id="buka">Buka Gembok🔒</button>

									

							<script>

											$(document).ready(function(){

  $("#next").click(function(){

    $("#div1").fadeIn(2000);

    $("#div2").fadeIn(3500);

    $("#div3").fadeIn(6000);

    $("#div4").fadeIn(8500);

    $("#div5").fadeIn(10000);

    $("#div6").fadeIn(11500);

    $("#div7").fadeIn(13000);

    $("#div8").fadeIn(14500);

    $("#buka").fadeIn(14800);

    

    

    

    

    

    

  });

});

$(document).ready(function(){

  $("#next").click(function(){

    $("#div1").fadeOut(300);

    $("#div2").fadeOut(300);

    $("#div3").fadeOut(300);

    $("#div4").fadeOut(300);

    $("#div5").fadeOut(300);

    $("#div6").fadeOut(300);

    $("#div7").fadeOut(300);

    $("#div8").fadeOut(300);

    $("#musik").fadeOut(300);

    

    

    

    

    

    $("#next").fadeOut(300);

    

    

  });

});		

							</script>						

					</div>

					

					<div class="kelima" id="kelima">

			<p class="aku" id="suka">Aku suka sama kamu</p>	   <p class="kamu" id="kamu">Kamu mau ga jadi pacar aku ?</p>

			<div class="hasil">

			<button class="mau" id="mau">Mau Doong😍</button>

			<button class="tidak" id="tidak">Tidak😡</button>

			</div>

			

									

					<script>

									$(document).ready(function(){

  $("#buka").click(function(){  

    $("#suka").fadeIn(3000);

    $("#kamu").fadeIn(3000);

    $("#buka").fadeOut(300);

    $("#mau").fadeIn(3000);

    $("#tidak").fadeIn(3000);

    

    

    

    });

});

									

					</script>

															

					</div>

					

					<div class="background" id="happy">

								

							

								

									<p class="love" id="love">❤</p>

									<p class="ikyy" id="ikyy">Ikyy</p>

								<p class="beb" id="hai"></p>

								<p class="jadian" id="jadian">Jadian<div id="hasil"></div></p>

								<hr>

								<p class="akhirnya" id="akhirnya">Akhirnya bisa pacarin kamuu</p>

								<img src="https://raw.githubusercontent.com/rifkipriyatna/Katakan-Cinta/main/dogy.gif"  class="dogy" id="dogy">

								

				</div>

				

			

	

 

	<script>

		var tanggal = new Date();

 

		document.getElementById("hasil").innerHTML = tanggal;

	</script>

	

	<script>

					$(document).ready(function(){

  $("#mau").click(function(){  

    

    $("#kelima").fadeOut(300);

    

    

    

    });

});

	</script>

								

								

								<script>

												$(document).ready(function(){

  $("#mau").click(function(){  

    $("#happy").fadeIn(3000);

    $("#love").fadeIn(3000);

    $("#hai").fadeIn(3000);

    $("#ikyy").fadeIn(3000);

    $("#jadian").fadeIn(3000);

    $("#akhirnya").fadeIn(3000);

    $("#dogy").fadeIn(3000);

    

    

    

    });

});

								</script>

					

					<div class="sad">

									

									<p class="love" id="sad">💔</p>

									<p class="ikyy" id="ikyyy">Ikyy</p>

								<p class="beb" id="hai"></p>

								<p class="jadian" id="tolak">Di Tolak</p>

								<div class="bapet" id="sst"></div>

								<hr class="hr" id="hr">

								<p class="akhirnya" id="yaudah">Yaudah deh gapapa🙃</p>

								<img src="https://raw.githubusercontent.com/rifkipriyatna/Katakan-Cinta/main/sad.gif"  class="dogy" id="sadd">

								

								<script>

							$(document).ready(function(){

  $("#tidak").click(function(){  

    $("#sad").fadeIn(3000);

    $("#ikyyy").fadeIn(3000);

    $("#hai").fadeIn(3000);

    $("#tolak").fadeIn(3000);

    $("#sst").fadeIn(3000);

    $("#yaudah").fadeIn(3000);

    $("#sadd").fadeIn(3000);

    $("#hr").fadeIn(3000);

    

    $("#kelima").fadeOut(300);

    

    

    

    });

});

							</script>

							<script>

											var tanggal = new Date();

 

		document.getElementById("sst").innerHTML = tanggal;

	</script>

	

							

									

									

					</div>

					

					

								

								

								

				</div>

				

				<style>

								body{

				background-image:url(https://raw.githubusercontent.com/rifkipriyatna/SIMP/main/bintang.jpeg);

}

.nama{

				margin:auto;

				display:block;

				border:none;

				text-decoration:none;

				background-color:#191919;

				opacity:0.7; font-size:12px;

				padding:6px;

				border-radius:5px;

				margin-top:30%;

				color:white;

}

.aw{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto;

				display:block;

				padding:4px;

				width:25%;

				font-weight:bold; font-size:13px;

				border-radius:5px;			

}

.semua{

				

				color:white;

}

.ha{

				display:none;

				

}

.hai{

				display:none;

				

}

.jadi{

				display:none;

				

}

.aku{

				display:none;

				

}

.sesuatu{

				display:none;

				

}

.kedua{

				text-align:center;

				font-weight:bold;

				font-family:Cursive;

				font-size:23px;

				

				

				

}

.apa{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto;

				display:none;

				padding:4px;

				width:25%;

				font-weight:bold; font-size:13px;

				border-radius:5px;		

				margin-top:30%;

				

}

.ketiga{

				text-align:center;

				font-weight:bold;

				font-family:Cursive;

				font-size:23px;

}

.tapi{

				display:none;

}

.denger{

				display:none;

}

.musik{

				width:20%;

				margin:auto;

				display:none;

}

.next{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto;

				display:none; font-size:13px;

				padding:4px;

				width:25%;

				font-weight:bold;

				border-radius:5px;		

				margin-top:30%;

}

.keempat{

				text-align:center;

				font-weight:bold;

				font-family:Cursive;

				font-size:23px;

}

.nembak{

				

				display:none;

				

}

.bahwa{

				

				display:none;

				

}

.sebener{

				

				display:none;

			  

}

.makan{

				

				display:none;

}

.jalan{

				

				display:none;

}

.chat{

				

				display:none;

}

.semuanya{

				

				display:none;

}

.jadi{

				display:none;

}

.buka{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto;

				display:none; font-size:13px;

				padding:4px;

				width:25%;

				font-weight:bold;

				border-radius:5px;		

				margin-top:30%;

}

.kelima{

				text-align:center;

				font-weight:bold;

				font-family:Cursive;

				font-size:23px;

}

.aku{

				display:none;

}

.kamu{

				display:none;

}

.mau{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto; font-size:13px;

				display:none;

				padding:3px;

				width:25%;

				font-weight:bold;

				border-radius:5px;	

				

}

.tidak{

				border:none;

				text-decoration:none;

				background-color:#191919;

				color:white;

				margin:auto;

				display:none; font-size:13px;

				padding:3px;

				width:20%;

				font-weight:bold;

				border-radius:5px;	

				

}

.background{

				width:60%;

				color:white;

				margin:auto;

				display:none;

				padding:10px;

				font-family:Cursive;

				border-radius:4px;

				opacity:0.8;

				

}

.beb{

				text-align:center;

				display:none;

}

.love{

				text-align:center;

				display:none;

				font-size:30px;

				margin-top:-19px;

}

.ikyy{

				text-align:center;

				display:none;

				font-size:26.5px;

				font-weight:bold;

}

.dogy{

				width:35%;

				margin-left:30%;

				display:none;

}

.jadian{

				text-align:center;

				display:none;

}

.akhirnya{

				text-align:center;

				display:none;			

}

.hr{		

				display:none;

}

.bapet{

				display:none;

}

.sad{

				width:60%;

				color:white;

				margin:auto;

				

				padding:10px;

				font-family:Cursive;

				border-radius:4px;

				opacity:0.8;

}

				</style>

</body>

</html>
